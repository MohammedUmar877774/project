﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace VOTINGSYSTEM
{
    public partial class creg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int a;
            string cnstr = (@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
            SqlConnection con = new SqlConnection(cnstr);
            con.Open();
            string query = "Select Max(id) from results";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    TextBox1.Text = "1";
                }
                else
                {
                    a = Convert.ToInt32(dr[0].ToString());
                    a = a + 1;
                    TextBox1.Text = a.ToString();
                }
            }
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             if (TextBox1.Text== "" || TextBox2.Text== "" || TextBox4.Text== "" || TextBox5.Text== "")
            {
                Response.Write("Missing Fields");
            }
            else
            {

                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
                {

                    if (DropDownList1.SelectedValue == "SPORTS CO-ORDINATOR")
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into sport values(@id,@name,@course,@email,@post,@password)", con);
                        SqlCommand cmd1 = new SqlCommand("insert into results values(@id,@post,@novotes,@name)", con);
                        cmd.Parameters.AddWithValue("@id", TextBox1.Text);
                        cmd.Parameters.AddWithValue("@name", TextBox2.Text);
                        cmd.Parameters.AddWithValue("@course", DropDownList2.SelectedValue);
                        cmd.Parameters.AddWithValue("@email", TextBox4.Text);
                        cmd.Parameters.AddWithValue("@post", DropDownList1.SelectedValue);
                        cmd.Parameters.AddWithValue("@password", TextBox5.Text);
                        cmd.ExecuteNonQuery();
                        cmd1.Parameters.AddWithValue("@id", TextBox1.Text);
                        cmd1.Parameters.AddWithValue("@name", TextBox2.Text);
                        cmd1.Parameters.AddWithValue("@post", DropDownList1.SelectedValue);
                        cmd1.Parameters.AddWithValue("@novotes", TextBox6.Text);
                        cmd1.ExecuteNonQuery();
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        DropDownList2.SelectedValue = "";
                        TextBox4.Text = "";
                        DropDownList1.SelectedValue = "";
                        Label6.Visible = true;
                        Label6.Text = "Register Succesfully";
                        con.Close();
                    }
                    else if (DropDownList1.SelectedValue == "STUDENT CO-ORDINATOR")
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into stud values(@id,@name,@course,@email,@post,@password)", con);
                        SqlCommand cmd1 = new SqlCommand("insert into results values(@id,@post,@novotes,@name)", con);
                        cmd.Parameters.AddWithValue("@id", TextBox1.Text);
                        cmd.Parameters.AddWithValue("@name", TextBox2.Text);
                        cmd.Parameters.AddWithValue("@course", DropDownList2.SelectedValue);
                        cmd.Parameters.AddWithValue("@email", TextBox4.Text);
                        cmd.Parameters.AddWithValue("@post", DropDownList1.SelectedValue);
                        cmd.Parameters.AddWithValue("@password", TextBox5.Text);
                        cmd.ExecuteNonQuery();
                        cmd1.Parameters.AddWithValue("@id", TextBox1.Text);
                        cmd1.Parameters.AddWithValue("@name", TextBox2.Text);
                        cmd1.Parameters.AddWithValue("@post", DropDownList1.SelectedValue);
                        cmd1.Parameters.AddWithValue("@novotes", TextBox6.Text);
                        cmd1.ExecuteNonQuery();
                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        DropDownList2.SelectedValue = "";
                        TextBox4.Text = "";
                        DropDownList1.SelectedValue = "";
                        Label6.Visible = true;
                        Label6.Text = "Register Succesfully";
                        con.Close();
                    }
                    else
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("insert into lc values(@id,@name,@course,@email,@post,@password)", con);
                        SqlCommand cmd1 = new SqlCommand("insert into results values(@id,@post,@novotes,@name)", con);
                        cmd.Parameters.AddWithValue("@id", TextBox1.Text);
                        cmd.Parameters.AddWithValue("@name", TextBox2.Text);
                        cmd.Parameters.AddWithValue("@course", DropDownList2.SelectedValue);
                        cmd.Parameters.AddWithValue("@email", TextBox4.Text);
                        cmd.Parameters.AddWithValue("@post", DropDownList1.SelectedValue);
                        cmd.Parameters.AddWithValue("@password", TextBox5.Text);
                        cmd.ExecuteNonQuery();
                        cmd1.Parameters.AddWithValue("@id", TextBox1.Text);
                        cmd1.Parameters.AddWithValue("@name", TextBox2.Text);
                        cmd1.Parameters.AddWithValue("@post", DropDownList1.SelectedValue);
                        cmd1.Parameters.AddWithValue("@novotes", TextBox6.Text);
                        cmd1.ExecuteNonQuery();

                        TextBox1.Text = "";
                        TextBox2.Text = "";
                        DropDownList2.SelectedValue = "";
                        TextBox4.Text = "";
                        DropDownList1.SelectedValue = "";
                        Label6.Visible = true;
                        Label6.Text = "Register Succesfully";
                        con.Close();
                        Response.Redirect("HOMEPAGE.aspx");
                    }
                }
            }

        }

        protected void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }

        protected void LinkButton1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }

       
    }
}