﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VOTINGSYSTEM
{
    public partial class HOMEPAGE : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                setimg();
            }
                
        }
        private void setimg()
        {
            Random ram = new Random();
            int i = ram.Next(1,5);
            Image1.ImageUrl = "~/Image/1.jpg";
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("creg.aspx");
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("vlog.aspx");
        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Response.Redirect("clogin.aspx");
        }


        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("adminlgn");
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

        }
    }
}