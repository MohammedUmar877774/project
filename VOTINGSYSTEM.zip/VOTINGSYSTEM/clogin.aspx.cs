﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace VOTINGSYSTEM
{
    public partial class clogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from lc where id=@id and password=@password ", con);
            cmd.Parameters.AddWithValue("@id", TextBox1.Text);
            cmd.Parameters.AddWithValue("@password", TextBox3.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("result.aspx");
            }
            else
            {
                Label3.Text = "Your username and word is incorrect";
            }
        }

        protected void LinkButton5_Click(object sender, EventArgs e)
        {

            LinkButton6.Visible = false;
            LinkButton7.Visible = false;
            Button2.Visible = false;
            Button3.Visible = false;
            Button1.Visible = true;
            Label2.Visible = true;
            TextBox1.Visible = true;
            Label4.Visible = true;
            TextBox3.Visible = true;
        }

        protected void LinkButton6_Click(object sender, EventArgs e)
        {
            LinkButton5.Visible = false;
            LinkButton7.Visible = false;
            Button1.Visible = false;
            Button3.Visible = false;
            Label2.Visible = true;
            TextBox1.Visible = true;
            Button2.Visible = true;
            Label4.Visible = true;
            TextBox3.Visible = true;

        }

        protected void LinkButton7_Click(object sender, EventArgs e)
        {
            LinkButton6.Visible = false;
            LinkButton5.Visible = false;
            Button2.Visible = false;
            Button1.Visible = false;
            Label2.Visible = true;
            TextBox1.Visible = true;
            Button3.Visible = true;
            Label4.Visible = true;
            TextBox3.Visible = true;

        }

        protected void Button2_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from stud where id=@id and password=@password ", con);
            cmd.Parameters.AddWithValue("@id", TextBox1.Text);
            cmd.Parameters.AddWithValue("@password", TextBox3.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("result.aspx");
            }
            else
            {
                Label3.Text = "Your username and word is incorrect";
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from sport where id=@id and password=@password ", con);
            cmd.Parameters.AddWithValue("@id", TextBox1.Text);
            cmd.Parameters.AddWithValue("@password", TextBox3.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count > 0)
            {
                Response.Redirect("result.aspx");
            }
            else
            {
                Label3.Text = "Your username and word is incorrect";
            }
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}