﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace VOTINGSYSTEM
{
    public partial class vlog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select * from voter where voter_id=@voter_id ", con);
            cmd.Parameters.AddWithValue("@voter_id", TextBox1.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (dt.Rows.Count  > 0) 
            {
                Session["name"] = TextBox1.Text;
                Response.Redirect("vopt.aspx");
 
            }
            else
            {
                Response.Write("<script LANGUAGE='JavaScript' >alert('Voter Id Invalid')</script>");

            }
           
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        { 
        }
    }
}