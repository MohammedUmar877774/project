﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace VOTINGSYSTEM
{
    public partial class vinsert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "" || TextBox2.Text == "" )
            {
                Response.Write("Missing Fields");
            }
            else
            {

                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("insert into voter values(@voter_id,@course)", con);
                    cmd.Parameters.AddWithValue("@voter_id", TextBox1.Text);
                    cmd.Parameters.AddWithValue("@course", TextBox2.Text);
                    cmd.ExecuteNonQuery();
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    Label3.Visible = true;
                    Label3.Text = "Register Succesfully";


                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "")
            {
                Response.Write("Missing Fields");
            }
            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("delete from voter where voter_id = @voter_id", con);
                    cmd.Parameters.AddWithValue("@voter_id", TextBox1.Text);
                    cmd.ExecuteNonQuery();
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    Label3.Text = "deleted  Succesfully";
                }
            }
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("admin.aspx");
        }
    }
}