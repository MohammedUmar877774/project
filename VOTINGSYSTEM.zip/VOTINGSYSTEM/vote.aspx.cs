﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace VOTINGSYSTEM
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox3.Text = Session["name"].ToString();
            Label6.Text = Session["name"].ToString();
            TextBox3.Visible = false;                       
            
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }
 
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");


            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT TOP 1000 [voter_id]FROM[final].[dbo].[checkvoters1] WHERE [voter_id] = @voter", con);
            //  cmd.Parameters.AddWithValue("@voter", TextBox3.Text);
            // int rdr = cmd.ExecuteScaler();
            //if (rdr.HasRows)
            // {
            //   Label7.Visible = true;
            // Label4.Visible = false;
            //}
            // else {


            SqlCommand cmd1 = new SqlCommand("UPDATE results set novotes = novotes + 1 where id =" + DropDownList1.SelectedItem, con);
            SqlCommand cmd2 = new SqlCommand("UPDATE results set novotes = novotes + 1 where id =" + DropDownList2.SelectedItem, con);
            SqlCommand cmd3 = new SqlCommand("UPDATE results set novotes = novotes + 1 where id =" + DropDownList3.SelectedItem, con);
            SqlCommand cmd4 = new SqlCommand("insert into checkvoters2 values(@voter_id)", con);
            cmd4.Parameters.AddWithValue("@voter_id", TextBox3.Text);
            cmd1.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            cmd3.ExecuteNonQuery();
            cmd4.ExecuteNonQuery();
            Response.Write("Done");
            con.Close();
            //Label7.Visible = false;
            Label4.Visible = true;

            
            
                Response.Write("<script LANGUAGE='JavaScript' >alert('Vote Casted Successfully')</script>");
            
                
            

        }

        protected void DropDownList3_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }










    }


}
    



    