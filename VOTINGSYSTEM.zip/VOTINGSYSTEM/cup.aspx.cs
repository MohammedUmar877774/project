﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace VOTINGSYSTEM
{
    public partial class cup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from stud where id = @id", con);
                cmd.Parameters.AddWithValue("@id", TextBox1.Text);
                cmd.ExecuteNonQuery();
                TextBox1.Text = "";
                Label7.Visible = true;
                Label7.Text = "deleted  Succesfully";
            }
        }

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("admin.aspx");
        }
    }
}