﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VOTINGSYSTEM
{
    public partial class vopt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label3.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VE3F4DH\SQLEXPRESS;Initial Catalog=final;Integrated Security=True");


            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM [final].[dbo].[checkvoters2] WHERE ([voter_id] = @voter)", con);
            cmd.Parameters.AddWithValue("@voter", Session["name"].ToString());
            SqlDataReader redr = cmd.ExecuteReader();
            if (redr.HasRows)
            {
                Label3.Visible = true;
            }
            else
            {
                Response.Redirect("vote.aspx");

            }

            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("result.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("HOMEPAGE.aspx");
        }
    }
}